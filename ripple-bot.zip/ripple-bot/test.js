'use strict';
const ripple = require('ripple-lib');

var request = require('request');


const RippleAPI = ripple.RippleAPI; // require('ripple-lib')

const api = new RippleAPI({server: 'wss://s1.ripple.com:443'});
// const address = 'rvYAfWj5gh67oV6fW32ZzP3Aw4Eubs59B';

const addresses = {
    bitstamp: 'rvYAfWj5gh67oV6fW32ZzP3Aw4Eubs59B',
    rippleChina: 'razqQKzJRdB4UxFPWf5NEpEG3WMkmwgcXA',
    rippleFox: 'rKiCet8SdvWxPXnAgYarFUXMh1zCPz432Y',
    gatehubFifth: 'rchGBxcD1A1C2tdxF6papQYZ8kjRKMYcL',
    gatehub: 'rhub8VRN55s94qWKDv6jmDy1pUykJzF3wq',
}


api.connect().then(() => {
    for (const key of Object.keys(addresses)) {
        const address = addresses[key];
        api.getSettings(address, {}).then(setting => {
            console.log('Fee of '+key+' is:'+ (setting.transferRate ? setting.transferRate: ' No Fee'));
        });
    }
});



function create(amount) {
    amount = Math.min(amount, 6.44);
    amount = amount.toFixed(2).toString();
    $.ajax({
        method: 'POST',
        url: '/Interest/Create',
        data: {
            CurrencyId: 12,
            Amount: amount,
        },
        dataType: "text",
        success: (function (resp) {
            console.info('Create');
            console.info(resp);
        })
    });
}

function iwantdeposit() {
    $.ajax({
        method: 'GET',
        url: '/Interest/Records',
        success: (function (resp) {
            for (var i = 0; i < resp.length; i++) {
                var currency = resp[i];
                if (currency.CurrencyId !== 12) {
                    continue;
                }
                var available = currency.MaxAmountLimit - currency.CurrentAmount;
                console.log(available);
                if (available > 0) {
                    create(available);
                }

            }
        }).bind(this)
    });
}

setInterval(iwantdeposit, 1000 * 4);

